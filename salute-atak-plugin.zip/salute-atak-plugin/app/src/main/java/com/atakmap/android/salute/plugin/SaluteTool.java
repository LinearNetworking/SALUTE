package com.atakmap.android.salute.plugin;

import android.content.Context;

import com.atak.plugins.impl.AbstractPluginTool;
import com.atakmap.android.salute.SaluteDropDownReceiver;

/** The toolbar button. Tapping it broadcasts SHOW_PLUGIN, which opens the drop-down. */
public class SaluteTool extends AbstractPluginTool {

    public SaluteTool(final Context context) {
        super(context,
                context.getString(R.string.app_name),
                context.getString(R.string.app_name),
                context.getResources().getDrawable(R.drawable.ic_salute),
                SaluteDropDownReceiver.SHOW_PLUGIN);
    }
}
