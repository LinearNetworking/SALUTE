package com.atakmap.android.salute.plugin;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;

import com.atak.plugins.impl.PluginContextProvider;
import com.atakmap.android.maps.MapComponent;
import com.atakmap.android.maps.MapView;
import com.atakmap.android.salute.SaluteMapComponent;
import com.atakmap.coremap.log.Log;

import java.util.Collection;
import java.util.LinkedList;

import gov.tak.api.plugin.IServiceController;
import transapps.maps.plugin.lifecycle.Lifecycle;

/** Entry point ATAK instantiates (see assets/plugin.xml). */
public class SaluteLifecycle implements Lifecycle {

    private static final String TAG = "SaluteLifecycle";

    private final Context pluginContext;
    private final Collection<MapComponent> overlays = new LinkedList<>();
    private MapView mapView;

    public SaluteLifecycle(IServiceController serviceController) {
        Context ctx = null;
        if (serviceController != null) {
            final PluginContextProvider provider =
                    serviceController.getService(PluginContextProvider.class);
            if (provider != null) ctx = provider.getPluginContext();
        }
        this.pluginContext = ctx;
        if (ctx != null) ctx.setTheme(R.style.ATAKPluginTheme);
    }

    @Override
    public void onCreate(final Activity activity, final transapps.mapi.MapView arg1) {
        if (pluginContext == null) return;
        mapView = (arg1 == null || !(arg1.getView() instanceof MapView))
                ? null : (MapView) arg1.getView();
        if (mapView == null) {
            Log.w(TAG, "no ATAK MapView available, SALUTE plugin not started");
            return;
        }
        overlays.add(new SaluteMapComponent());
        for (MapComponent c : overlays) {
            c.onCreate(pluginContext, activity.getIntent(), mapView);
        }
    }

    @Override public void onStart() {
        for (MapComponent c : overlays) c.onStart(pluginContext, mapView);
    }
    @Override public void onPause() {
        for (MapComponent c : overlays) c.onPause(pluginContext, mapView);
    }
    @Override public void onResume() {
        for (MapComponent c : overlays) c.onResume(pluginContext, mapView);
    }
    @Override public void onStop() {
        for (MapComponent c : overlays) c.onStop(pluginContext, mapView);
    }
    @Override public void onDestroy() {
        for (MapComponent c : overlays) c.onDestroy(pluginContext, mapView);
        overlays.clear();
    }
    @Override public void onConfigurationChanged(Configuration newConfig) {
        for (MapComponent c : overlays) c.onConfigurationChanged(newConfig);
    }
    @Override public void onFinish() { }
}
