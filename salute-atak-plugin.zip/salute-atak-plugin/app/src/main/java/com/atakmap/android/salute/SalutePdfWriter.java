package com.atakmap.android.salute;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Renders a SALUTE report to a multi-page A4 PDF using Android's built-in PdfDocument. */
final class SalutePdfWriter {

    private static final int W = 595, H = 842, M = 40;   // A4 in points, margin

    private final PdfDocument doc = new PdfDocument();
    private PdfDocument.Page page;
    private Canvas canvas;
    private int pageNo = 0;
    private float y;

    private final TextPaint title = paint(22, Color.BLACK, true);
    private final TextPaint label = paint(10, Color.rgb(70, 90, 60), true);
    private final TextPaint body = paint(13, Color.BLACK, false);
    private final TextPaint small = paint(9, Color.DKGRAY, false);

    private static TextPaint paint(float size, int color, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(size);
        p.setColor(color);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return p;
    }

    private static String utc(Date d, String pattern) {
        SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(d);
    }

    static File write(File dir, SaluteReport r) throws IOException {
        return new SalutePdfWriter().render(dir, r);
    }

    private File render(File dir, SaluteReport r) throws IOException {
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create folder " + dir);
        Date now = new Date();

        newPage();
        canvas.drawText("SALUTE REPORT", M, y + title.getTextSize(), title);
        y += title.getTextSize() + 8;
        Paint line = new Paint();
        line.setColor(Color.GRAY);
        canvas.drawLine(M, y, W - M, y, line);
        y += 12;

        row("REPORTED BY", r.callsign);
        row("OBSERVATION TIME (UTC)", r.time != null ? r.time : utc(now, "yyyy-MM-dd'T'HH:mm:ss'Z'"));
        row("AFFILIATION", r.affiliationLabel());
        if (!r.mission.isEmpty()) row("MISSION", r.mission);
        y += 6;
        row("S - SIZE", r.size);
        row("A - ACTIVITY", r.activity);
        row("L - LOCATION", String.format(Locale.US, "%.6f, %.6f", r.lat, r.lon));
        row("U - UNIT", r.unit);
        row("T - TIME", r.time != null ? r.time : "Time of report");
        row("E - EQUIPMENT", r.equipment);
        row("H - HABITS", r.habits);
        row("I - INTENTIONS", r.intentions);
        row("M - MORALE", r.morale);

        finishPage("Saved locally " + utc(now, "yyyy-MM-dd HH:mm") + "Z - not transmitted to a server");

        File out = new File(dir, "SALUTE_" + r.callsign.replaceAll("[^A-Za-z0-9_-]", "_")
                + "_" + utc(now, "yyyyMMdd'T'HHmmss'Z'") + ".pdf");
        try (FileOutputStream os = new FileOutputStream(out)) {
            doc.writeTo(os);
        } finally {
            doc.close();
        }
        return out;
    }

    private void row(String lbl, String val) {
        if (val == null || val.trim().isEmpty()) return;     // optional H/I/M left blank
        StaticLayout sl = new StaticLayout(val, body, W - 2 * M,
                Layout.Alignment.ALIGN_NORMAL, 1.15f, 0f, false);
        float need = label.getTextSize() + 4 + sl.getHeight() + 14;
        if (y + need > H - M - 20) { finishPage(null); newPage(); }
        y += label.getTextSize();
        canvas.drawText(lbl, M, y, label);
        y += 4;
        canvas.save();
        canvas.translate(M, y);
        sl.draw(canvas);
        canvas.restore();
        y += sl.getHeight() + 14;
    }

    private void newPage() {
        pageNo++;
        page = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, pageNo).create());
        canvas = page.getCanvas();
        y = M;
    }

    private void finishPage(String footerNote) {
        String foot = (footerNote != null ? footerNote + "   |   " : "") + "Page " + pageNo;
        canvas.drawText(foot, M, H - M / 2f, small);
        doc.finishPage(page);
    }
}
