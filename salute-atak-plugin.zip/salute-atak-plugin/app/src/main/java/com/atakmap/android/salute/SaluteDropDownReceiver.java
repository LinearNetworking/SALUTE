package com.atakmap.android.salute;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.atak.plugins.impl.PluginLayoutInflater;
import com.atakmap.android.dropdown.DropDown;
import com.atakmap.android.dropdown.DropDownReceiver;
import com.atakmap.android.maps.MapView;
import com.atakmap.android.salute.plugin.R;
import com.atakmap.coremap.filesystem.FileSystemUtils;
import com.atakmap.coremap.log.Log;
import com.atakmap.coremap.maps.coords.GeoPoint;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The SALUTE form shown in ATAK's drop-down pane. */
public class SaluteDropDownReceiver extends DropDownReceiver implements DropDown.OnStateListener {

    private static final String TAG = "SaluteDropDown";
    public static final String SHOW_PLUGIN = "com.atakmap.android.salute.SHOW_PLUGIN";

    /** Same order as @array/affiliation_labels. */
    private static final String[] AFFIL_VALUES = {"a-u-G", "a-h-G", "a-s-G", "a-n-G", "a-f-G"};
    private static final String DEFAULT_MISSION_LABEL = "Server default";
    private static final String OTHER_MISSION_LABEL = "Other (type a name)...";

    private final MapView mapView;
    private final Context pluginContext;
    private final View root;
    private final SaluteSettings settings;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final List<String> missionItems = new ArrayList<>();
    private ArrayAdapter<String> missionAdapter;

    private EditText etCallsign, etSize, etActivity, etLat, etLon, etUnit, etTime, etEquipment,
            etHabits, etIntentions, etMorale, etMissionOther, etStale;
    private Spinner spAffil, spMission;
    private CheckBox cbPackage;
    private Button btnSend, btnPdf, btnRefresh;
    private TextView txtServer, txtResult;

    public SaluteDropDownReceiver(final MapView mapView, final Context pluginContext) {
        super(mapView);
        this.mapView = mapView;
        this.pluginContext = pluginContext;
        this.settings = new SaluteSettings(mapView.getContext());
        this.root = PluginLayoutInflater.inflate(pluginContext, R.layout.salute_main, null);
        bindViews();
        wireActions();
    }

    // ------------------------------------------------------------------ setup

    @SuppressWarnings("unchecked")
    private <T extends View> T v(int id) { return (T) root.findViewById(id); }

    private void bindViews() {
        etCallsign = v(R.id.et_callsign);   etSize = v(R.id.et_size);
        etActivity = v(R.id.et_activity);   etLat = v(R.id.et_lat);
        etLon = v(R.id.et_lon);             etUnit = v(R.id.et_unit);
        etTime = v(R.id.et_time);           etEquipment = v(R.id.et_equipment);
        etHabits = v(R.id.et_habits);       etIntentions = v(R.id.et_intentions);
        etMorale = v(R.id.et_morale);       etMissionOther = v(R.id.et_mission_other);
        etStale = v(R.id.et_stale);
        spAffil = v(R.id.sp_affiliation);   spMission = v(R.id.sp_mission);
        cbPackage = v(R.id.cb_package);
        btnSend = v(R.id.btn_send);         btnPdf = v(R.id.btn_pdf);
        btnRefresh = v(R.id.btn_refresh_missions);
        txtServer = v(R.id.txt_server);     txtResult = v(R.id.txt_result);

        ArrayAdapter<CharSequence> affil = ArrayAdapter.createFromResource(
                pluginContext, R.array.affiliation_labels, android.R.layout.simple_spinner_item);
        affil.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spAffil.setAdapter(affil);

        missionItems.add(DEFAULT_MISSION_LABEL);
        missionItems.add(OTHER_MISSION_LABEL);
        missionAdapter = new ArrayAdapter<>(pluginContext, android.R.layout.simple_spinner_item, missionItems);
        missionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMission.setAdapter(missionAdapter);
    }

    private void wireActions() {
        ((Button) v(R.id.btn_settings)).setOnClickListener(x -> showSettings());
        ((Button) v(R.id.btn_my_pos)).setOnClickListener(x -> useMyPosition());
        ((Button) v(R.id.btn_map_center)).setOnClickListener(x -> useMapCenter());
        btnRefresh.setOnClickListener(x -> loadMissions(true));
        btnSend.setOnClickListener(x -> onSend());
        btnPdf.setOnClickListener(x -> onSavePdf());
        spMission.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View view, int pos, long id) {
                etMissionOther.setVisibility(pos == missionItems.size() - 1 ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
    }

    // ------------------------------------------------------------------ show / state

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!SHOW_PLUGIN.equals(intent.getAction())) return;
        showDropDown(root, HALF_WIDTH, FULL_HEIGHT, FULL_WIDTH, HALF_HEIGHT, false, this);
        if (s(etCallsign).isEmpty()) etCallsign.setText(mapView.getDeviceCallsign());
        if (s(etLat).isEmpty() && s(etLon).isEmpty()) useMyPosition();
        refreshServerState();
        if (settings.hasServer()) loadMissions(false);
    }

    private void refreshServerState() {
        final boolean has = settings.hasServer();
        txtServer.setText(has
                ? "Server: " + settings.getServerUrl()
                : "No server set - reports can be saved as a PDF on this device.");
        spMission.setEnabled(has);
        btnRefresh.setEnabled(has);
        cbPackage.setEnabled(has);
        btnSend.setText(has ? "Send to server" : "Send (set a server in Settings)");
        btnSend.setAlpha(has ? 1f : 0.6f);
    }

    // ------------------------------------------------------------------ location helpers

    private void useMyPosition() {
        try {
            GeoPoint p = mapView.getSelfMarker().getPoint();
            if (p != null && p.isValid()) setPoint(p);
            else toast("No GPS fix yet");
        } catch (Exception e) {
            toast("No GPS fix yet");
        }
    }

    private void useMapCenter() {
        try {
            GeoPoint p = mapView.getCenterPoint().get();
            if (p != null && p.isValid()) setPoint(p);
        } catch (Exception e) {
            Log.w(TAG, "map center unavailable", e);
        }
    }

    private void setPoint(GeoPoint p) {
        etLat.setText(String.format(Locale.US, "%.6f", p.getLatitude()));
        etLon.setText(String.format(Locale.US, "%.6f", p.getLongitude()));
    }

    // ------------------------------------------------------------------ missions

    private void loadMissions(final boolean refresh) {
        final String server = settings.getServerUrl();
        if (server.isEmpty()) return;
        io.execute(() -> {
            SaluteApi.Missions m = null;
            String err = null;
            try { m = SaluteApi.missions(server, refresh); }
            catch (Exception e) { err = e.getMessage(); }
            final SaluteApi.Missions fm = m;
            final String ferr = err;
            ui(() -> {
                if (fm != null && fm.ok) rebuildMissionItems(fm.names);
                else toast("Mission list unavailable: " + (fm != null ? fm.error : ferr));
            });
        });
    }

    private void rebuildMissionItems(List<String> names) {
        Object keep = spMission.getSelectedItem();
        missionItems.clear();
        missionItems.add(DEFAULT_MISSION_LABEL);
        missionItems.addAll(names);
        missionItems.add(OTHER_MISSION_LABEL);
        missionAdapter.notifyDataSetChanged();
        int idx = keep == null ? -1 : missionItems.indexOf(keep.toString());
        spMission.setSelection(idx >= 0 ? idx : 0);
    }

    private String selectedMission() {
        int pos = spMission.getSelectedItemPosition();
        if (pos <= 0) return "";
        if (pos == missionItems.size() - 1) return s(etMissionOther);
        return missionItems.get(pos);
    }

    // ------------------------------------------------------------------ form -> report

    private static String s(EditText e) { return e.getText().toString().trim(); }

    private static double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim()); }
        catch (NumberFormatException ex) { return Double.NaN; }
    }

    /** "2026-10-30 14:05" (UTC) -> ISO-8601, or null if unparsable. */
    private static String parseDtg(String in) {
        String t = in.trim().replace('T', ' ').replaceAll("[zZ]$", "").trim();
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            f.setLenient(false);
            java.util.Date d = f.parse(t);
            SimpleDateFormat o = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            o.setTimeZone(TimeZone.getTimeZone("UTC"));
            return o.format(d);
        } catch (ParseException e) {
            return null;
        }
    }

    /** Returns null (after showing the problems) if the form is not valid yet. */
    private SaluteReport readForm() {
        SaluteReport r = new SaluteReport();
        r.callsign = s(etCallsign);   r.size = s(etSize);
        r.activity = s(etActivity);   r.unit = s(etUnit);
        r.equipment = s(etEquipment); r.habits = s(etHabits);
        r.intentions = s(etIntentions); r.morale = s(etMorale);
        r.lat = num(etLat);           r.lon = num(etLon);
        r.affiliation = AFFIL_VALUES[Math.max(0, spAffil.getSelectedItemPosition())];
        r.mission = settings.hasServer() ? selectedMission() : "";

        List<String> errors = new ArrayList<>();
        String t = s(etTime);
        if (!t.isEmpty()) {
            r.time = parseDtg(t);
            if (r.time == null) errors.add("Time must look like 2026-10-30 14:05 (UTC), or be blank");
        }
        errors.addAll(r.validate());
        if (!errors.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (String e : errors) sb.append("- ").append(e).append('\n');
            new AlertDialog.Builder(mapView.getContext())
                    .setTitle("Check the report").setMessage(sb.toString().trim())
                    .setPositiveButton("OK", null).show();
            return null;
        }
        return r;
    }

    private int staleMinutes() {
        try { return Math.max(1, Integer.parseInt(s(etStale))); }
        catch (NumberFormatException e) { return 60; }
    }

    // ------------------------------------------------------------------ send / PDF

    private void onSend() {
        final SaluteReport r = readForm();
        if (r == null) return;
        final String server = settings.getServerUrl();
        if (server.isEmpty()) {
            offerPdf("No SALUTE server is set.", r, true);
            return;
        }
        final boolean pkg = cbPackage.isChecked();
        final int stale = staleMinutes();
        setBusy(true, "Sending...");
        io.execute(() -> {
            try {
                final SaluteApi.Result res = SaluteApi.post(server, r.toJson(pkg, stale));
                ui(() -> {
                    setBusy(false, null);
                    if (res.ok) {
                        StringBuilder sb = new StringBuilder("Sent. UID: " + res.uid);
                        if (res.mission != null) sb.append("\nMission: ").append(res.mission);
                        if (res.packageUrl != null)
                            sb.append("\nData package: ").append(server).append('/').append(res.packageUrl);
                        txtResult.setText(sb.toString());
                    } else {
                        txtResult.setText("Server rejected the report: " + res.message
                                + "\nYou can still save it as a PDF.");
                    }
                });
            } catch (final Exception e) {
                Log.w(TAG, "send failed", e);
                ui(() -> {
                    setBusy(false, null);
                    offerPdf("Could not reach the server (" + e.getMessage() + ").", r, false);
                });
            }
        });
    }

    private void onSavePdf() {
        final SaluteReport r = readForm();
        if (r != null) savePdf(r);
    }

    private void offerPdf(String reason, final SaluteReport r, boolean offerSettings) {
        AlertDialog.Builder b = new AlertDialog.Builder(mapView.getContext())
                .setTitle("Not sent")
                .setMessage(reason + "\n\nSave this report as a PDF on this device instead?")
                .setPositiveButton("Save PDF", (d, w) -> savePdf(r))
                .setNegativeButton("Cancel", null);
        if (offerSettings) b.setNeutralButton("Settings", (d, w) -> showSettings());
        b.show();
    }

    private void savePdf(final SaluteReport r) {
        setBusy(true, "Saving PDF...");
        io.execute(() -> {
            try {
                File dir = FileSystemUtils.getItem("tools/salute");
                final File f = SalutePdfWriter.write(dir, r);
                ui(() -> {
                    setBusy(false, null);
                    txtResult.setText("Saved PDF on this device:\n" + f.getAbsolutePath());
                    toast("PDF saved: " + f.getName());
                });
            } catch (final Exception e) {
                Log.e(TAG, "pdf failed", e);
                ui(() -> {
                    setBusy(false, null);
                    txtResult.setText("Could not save PDF: " + e.getMessage());
                });
            }
        });
    }

    private void setBusy(boolean busy, String msg) {
        btnSend.setEnabled(!busy);
        btnPdf.setEnabled(!busy);
        if (msg != null) txtResult.setText(msg);
    }

    // ------------------------------------------------------------------ settings dialog

    private void showSettings() {
        final Context ctx = mapView.getContext();
        final float dp = ctx.getResources().getDisplayMetrics().density;
        final int pad = (int) (16 * dp);

        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad / 2, pad, 0);

        TextView hint = new TextView(ctx);
        hint.setText("SALUTE server: the base URL of the Node-RED SALUTE flow, "
                + "e.g. http://192.168.1.50:1880\n(use http://user:pass@host:1880 if it needs a login)."
                + "\n\nLeave blank to work without a server - reports can then be saved as PDF.");
        box.addView(hint);

        final EditText url = new EditText(ctx);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setHint("http://host:1880");
        url.setText(settings.getRawServerUrl());
        url.setSingleLine(true);
        box.addView(url);

        final TextView status = new TextView(ctx);
        box.addView(status);

        final AlertDialog d = new AlertDialog.Builder(ctx)
                .setTitle("SALUTE settings")
                .setView(box)
                .setPositiveButton("Save", null)     // overridden below so invalid input keeps the dialog open
                .setNeutralButton("Test", null)
                .setNegativeButton("Cancel", null)
                .create();
        d.show();

        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            String text = url.getText().toString();
            if (!SaluteSettings.isValid(text)) {
                status.setText("That does not look like a valid http(s) address.");
                return;
            }
            settings.setServerUrl(text);
            refreshServerState();
            if (settings.hasServer()) loadMissions(true);
            d.dismiss();
        });

        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(x -> {
            final String text = url.getText().toString();
            if (!SaluteSettings.isValid(text) || SaluteSettings.normalize(text).isEmpty()) {
                status.setText("Enter a valid server address to test.");
                return;
            }
            status.setText("Testing...");
            final String base = SaluteSettings.normalize(text);
            io.execute(() -> {
                final String err = SaluteApi.test(base);
                ui(() -> status.setText(err == null ? "Connected to the SALUTE flow." : err));
            });
        });
    }

    // ------------------------------------------------------------------ misc

    private void ui(Runnable r) { mapView.post(r); }

    private void toast(String m) { Toast.makeText(mapView.getContext(), m, Toast.LENGTH_LONG).show(); }

    @Override public void disposeImpl() { io.shutdownNow(); }
    @Override public void onDropDownSelectionRemoved() { }
    @Override public void onDropDownVisible(boolean v) { }
    @Override public void onDropDownSizeChanged(double w, double h) { }
    @Override public void onDropDownClose() { }
}
