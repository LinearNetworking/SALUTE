package com.atakmap.android.salute;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** One SALUTE (+ H.I.M.) report. Field names match what the Node-RED flow's POST /salute expects. */
final class SaluteReport {
    String callsign = "", size = "", activity = "", unit = "", equipment = "";
    String habits = "", intentions = "", morale = "";
    String affiliation = "a-u-G";
    String mission = "";
    /** ISO-8601 UTC observation time, or null meaning "now". */
    String time;
    double lat = Double.NaN, lon = Double.NaN;

    /** Same rules the flow enforces server-side. */
    List<String> validate() {
        List<String> e = new ArrayList<>();
        if (callsign.isEmpty()) e.add("Callsign is required");
        if (size.isEmpty()) e.add("S - Size is required");
        if (activity.isEmpty()) e.add("A - Activity is required");
        if (unit.isEmpty()) e.add("U - Unit is required");
        if (equipment.isEmpty()) e.add("E - Equipment is required");
        if (!(lat >= -90 && lat <= 90)) e.add("Latitude must be -90 to 90");
        if (!(lon >= -180 && lon <= 180)) e.add("Longitude must be -180 to 180");
        return e;
    }

    JSONObject toJson(boolean buildPackage, int staleMinutes) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("callsign", callsign);
        o.put("size", size);
        o.put("activity", activity);
        o.put("lat", lat);
        o.put("lon", lon);
        o.put("unit", unit);
        if (time != null && !time.isEmpty()) o.put("time", time);
        o.put("equipment", equipment);
        o.put("habits", habits);
        o.put("intentions", intentions);
        o.put("morale", morale);
        o.put("affiliation", affiliation);
        o.put("staleMinutes", staleMinutes);
        o.put("package", buildPackage);
        if (!mission.isEmpty()) o.put("mission", mission);
        return o;
    }

    String affiliationLabel() {
        switch (affiliation) {
            case "a-h-G": return "Hostile";
            case "a-s-G": return "Suspect";
            case "a-n-G": return "Neutral";
            case "a-f-G": return "Friendly";
            default: return "Unknown";
        }
    }
}
