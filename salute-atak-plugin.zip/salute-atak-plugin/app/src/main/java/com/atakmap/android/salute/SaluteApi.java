package com.atakmap.android.salute;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Talks to the Node-RED flow: POST /salute, GET /salute/missions, GET /salute/config. */
final class SaluteApi {

    static final class Result {
        boolean ok;
        String message = "";
        String uid, mission, packageUrl;
    }

    static final class Missions {
        boolean ok;
        String error = "";
        final List<String> names = new ArrayList<>();
    }

    private static HttpURLConnection open(String base, String path, String method) throws IOException {
        URL url = new URL(base + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(6000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Accept", "application/json");
        // http://user:pass@host:1880 -> Basic auth (matches Node-RED httpNodeAuth)
        String ui = url.getUserInfo();
        if (ui != null && !ui.isEmpty()) {
            c.setRequestProperty("Authorization", "Basic "
                    + Base64.encodeToString(ui.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP));
        }
        return c;
    }

    private static String readBody(HttpURLConnection c) throws IOException {
        InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        }
    }

    static Result post(String base, JSONObject body) throws IOException {
        HttpURLConnection c = open(base, "/salute", "POST");
        try {
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setFixedLengthStreamingMode(data.length);
            try (OutputStream os = c.getOutputStream()) { os.write(data); }

            int code = c.getResponseCode();
            String text = readBody(c);
            Result r = new Result();
            try {
                JSONObject j = new JSONObject(text);
                r.ok = code == 200 && j.optBoolean("ok", false);
                if (!j.isNull("uid")) r.uid = j.optString("uid");
                if (!j.isNull("mission")) r.mission = j.optString("mission");
                if (!j.isNull("packageUrl")) r.packageUrl = j.optString("packageUrl");
                JSONArray errs = j.optJSONArray("errors");
                if (errs != null) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < errs.length(); i++) {
                        if (i > 0) sb.append("; ");
                        sb.append(errs.optString(i));
                    }
                    r.message = sb.toString();
                }
            } catch (JSONException e) {
                r.ok = false;
                r.message = "Unexpected reply from server (HTTP " + code + ")";
            }
            if (!r.ok && r.message.isEmpty()) r.message = "Server returned HTTP " + code;
            return r;
        } finally {
            c.disconnect();
        }
    }

    static Missions missions(String base, boolean refresh) throws IOException {
        HttpURLConnection c = open(base, "/salute/missions" + (refresh ? "?refresh=1" : ""), "GET");
        Missions m = new Missions();
        try {
            String text = readBody(c);
            try {
                JSONObject j = new JSONObject(text);
                m.ok = j.optBoolean("ok", false);
                if (!m.ok) m.error = j.optString("error", "mission list unavailable");
                JSONArray a = j.optJSONArray("missions");
                if (a != null) for (int i = 0; i < a.length(); i++) m.names.add(a.optString(i));
            } catch (JSONException e) {
                m.error = "unexpected reply (HTTP " + c.getResponseCode() + ")";
            }
            return m;
        } finally {
            c.disconnect();
        }
    }

    /** Cheap health check: the flow's /salute/config endpoint. Returns null if OK, else an error text. */
    static String test(String base) {
        HttpURLConnection c = null;
        try {
            c = open(base, "/salute/config", "GET");
            int code = c.getResponseCode();
            readBody(c);
            return code == 200 ? null : "Server answered HTTP " + code + " (is this the SALUTE flow?)";
        } catch (IOException e) {
            return "Cannot connect: " + e.getMessage();
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
