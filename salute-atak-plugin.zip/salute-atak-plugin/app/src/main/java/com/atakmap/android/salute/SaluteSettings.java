package com.atakmap.android.salute;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.net.MalformedURLException;
import java.net.URL;

/** Stores the SALUTE server (Node-RED base URL) in ATAK's shared preferences. */
final class SaluteSettings {
    private static final String KEY_SERVER = "plugin.salute.server_url";
    private final SharedPreferences prefs;

    SaluteSettings(Context atakContext) {
        prefs = PreferenceManager.getDefaultSharedPreferences(atakContext);
    }

    /** Normalised base URL, or "" when no server is configured. */
    String getServerUrl() { return normalize(prefs.getString(KEY_SERVER, "")); }
    String getRawServerUrl() { return prefs.getString(KEY_SERVER, ""); }
    boolean hasServer() { return !getServerUrl().isEmpty(); }
    void setServerUrl(String url) { prefs.edit().putString(KEY_SERVER, normalize(url)).apply(); }

    static String normalize(String s) {
        s = s == null ? "" : s.trim();
        if (s.isEmpty()) return "";
        if (!s.matches("(?i)^https?://.*")) s = "http://" + s;
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    /** True for "" (offline mode) or a well-formed http(s) URL. */
    static boolean isValid(String s) {
        String n = normalize(s);
        if (n.isEmpty()) return true;
        try {
            URL u = new URL(n);
            return u.getHost() != null && !u.getHost().isEmpty();
        } catch (MalformedURLException e) {
            return false;
        }
    }
}
