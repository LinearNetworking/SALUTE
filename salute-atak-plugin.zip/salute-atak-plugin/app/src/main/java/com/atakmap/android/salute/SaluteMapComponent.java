package com.atakmap.android.salute;

import android.content.Context;
import android.content.Intent;

import com.atakmap.android.dropdown.DropDownMapComponent;
import com.atakmap.android.ipc.AtakBroadcast;
import com.atakmap.android.maps.MapView;
import com.atakmap.android.salute.plugin.R;

public class SaluteMapComponent extends DropDownMapComponent {

    private SaluteDropDownReceiver receiver;

    @Override
    public void onCreate(final Context context, Intent intent, final MapView view) {
        context.setTheme(R.style.ATAKPluginTheme);
        super.onCreate(context, intent, view);

        receiver = new SaluteDropDownReceiver(view, context);
        AtakBroadcast.DocumentedIntentFilter filter = new AtakBroadcast.DocumentedIntentFilter();
        filter.addAction(SaluteDropDownReceiver.SHOW_PLUGIN, "Show the SALUTE report tool");
        registerDropDownReceiver(receiver, filter);
    }

    @Override
    protected void onDestroyImpl(Context context, MapView view) {
        super.onDestroyImpl(context, view);
    }
}
